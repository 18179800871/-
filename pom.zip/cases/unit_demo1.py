import unittest
from ddt import ddt,data,file_data
from selenium import webdriver
from base.chrome_options import Options
from  base.log import Logger
from page_object.demo1 import LoginPage
from page_object.demo2 import ProductPage

@ddt
class Cases(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.driver = webdriver.Chrome(options=Options().options_conf())
        cls.lp = LoginPage(cls.driver)
        cls.pg = ProductPage(cls.driver)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.driver.quit()

    @file_data('../data/user.yaml')
    def test_01_login(self,**kwargs):
        self.lp.login(kwargs['user'], kwargs['pwd'])

    def test_02_addcart(self):
        self.pg.addcart()










