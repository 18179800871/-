from HTMLTestReportCN import HTMLTestRunner
import os
import unittest

suite = unittest.TestSuite()
case_dir = './'
# 基于路径来用例,组合成套件 常用方法
disciver = unittest.defaultTestLoader.discover(start_dir=case_dir , pattern='unit*.py')
# 设置保存路径
report_path = './report/'
#报告的文件名称
report_file = report_path + 'report1.html'
if not os.path.exists(report_path):
    os.mkdir(report_path)
with open(report_file , 'wb') as file:
    runner = HTMLTestRunner(stream=file,title='第一份测试报告',description='这是测试报告的描述',tester='沈华明')
    runner.run(disciver)































